# Meu dicionario pra armazenar as infos
books = []